import ChordLyricsPair from './chord_sheet/chord_lyrics_pair';
import Evaluatable from './chord_sheet/chord_pro/evaluatable';
import Font from './chord_sheet/font';
import Item from './chord_sheet/item';
import Line from './chord_sheet/line';
import Metadata from './chord_sheet/metadata';
import { MetadataConfiguration } from './formatter/configuration/base_configuration';
import MetadataProcessor from './template_helpers/metadata_processor';
import Paragraph from './chord_sheet/paragraph';
import Tag from './chord_sheet/tag';
import When from './template_helpers/when';
import WhenCallback from './template_helpers/when_callback';

import { renderChord } from './helpers';
import { INDETERMINATE, NONE } from './constants';
import { Literal, SoftLineBreak } from './index';
import { hasChordContents, isEmptyString, isEvaluatable } from './utilities';

import {
  Configuration,
  Delegate,
  HtmlTemplateCssClasses,
  defaultDelegate,
} from './formatter/configuration';

type EachCallback = (_item: any) => string;

export { hasChordContents, isEvaluatable } from './utilities';
export { renderChord } from './helpers';

import { pangoToHtml, stripPangoMarkup } from './pango/pango_helpers';
export { pangoToHtml, stripPangoMarkup };

export function isChordLyricsPair(item: Item): boolean {
  return item instanceof ChordLyricsPair;
}

export function isRhythmSymbol(item: Item): boolean {
  return item instanceof ChordLyricsPair && item.isRhythmSymbol;
}

export function lineHasContents(line: Line): boolean {
  return line.items.some((item: Item) => item.isRenderable());
}

export function isTag(item: Item): boolean {
  return item instanceof Tag;
}

export function isLiteral(item: Item): boolean {
  return item instanceof Literal;
}

export function isComment(item: Tag): boolean {
  return item.name === 'comment';
}

export function isImage(item: Tag): boolean {
  return item.name === 'image';
}

export function imageTag(item: Tag): string {
  const src = item.attributes.src || item.value;
  const width = item.attributes.width ? ` width="${item.attributes.width}"` : '';
  const height = item.attributes.height ? ` height="${item.attributes.height}"` : '';
  return `<img src="${src}"${width}${height}>`;
}

export function isColumnBreak(item: Item): boolean {
  return item instanceof Tag && item.name === 'column_break';
}

export function isSoftLineBreak(item: Item): boolean {
  return item instanceof SoftLineBreak;
}

export function stripHTML(string: string): string {
  return string
    .trim()
    .replace(/(<\/[a-z]+>)\s+(<)/g, '$1$2')
    .replace(/(>)\s+(<\/[a-z]+>)/g, '$1$2')
    .replace(/(\n)\s+/g, '');
}

export function newlinesToBreaks(string: string): string {
  return string.replace(/\n/g, '<br>');
}

export function renderSection(paragraph: Paragraph, configuration: Configuration): string {
  const delegate: Delegate = configuration.delegates[paragraph.type] || defaultDelegate;

  return delegate(paragraph.contents);
}

export function each(collection: any[], callback: EachCallback): string {
  return collection.map(callback).join('');
}

export function when(condition: any, callback?: WhenCallback): When {
  return new When(condition, callback);
}

export function hasTextContents(line: Line): boolean {
  return line.items.some((item) => (
    (item instanceof ChordLyricsPair && !isEmptyString(item.lyrics)) ||
    (item instanceof Tag && item.isRenderable()) ||
    isEvaluatable(item)
  ));
}

export function lineClasses(line: Line, cssClasses: HtmlTemplateCssClasses): string {
  const classes = [cssClasses.row];

  if (!lineHasContents(line)) {
    classes.push(cssClasses.emptyLine);
  }

  return classes.join(' ');
}

export function paragraphClasses(paragraph: Paragraph, cssClasses: HtmlTemplateCssClasses): string {
  const classes = [cssClasses.paragraph];

  if (paragraph.type !== INDETERMINATE && paragraph.type !== NONE) {
    classes.push(paragraph.type);
  }

  return classes.join(' ');
}

export function evaluate(item: Evaluatable, metadata: Metadata, configuration: Configuration): string {
  return item.evaluate(metadata, configuration.metadata.separator);
}

export function fontStyleTag(font: Font): string {
  const cssString = font.toCssString();

  if (cssString) {
    return ` style="${cssString}"`;
  }

  return '';
}

export function processMetadata(
  metadata: Record<string, string | string[]>,
  config: MetadataConfiguration,
): [string, string | string[]][] {
  return new MetadataProcessor(metadata, config).process();
}

export default {
  isLiteral,
  isSoftLineBreak,
  isEvaluatable,
  isChordLyricsPair,
  lineHasContents,
  isTag,
  isComment,
  isImage,
  isColumnBreak,
  stripHTML,
  each,
  when,
  hasTextContents,
  lineClasses,
  paragraphClasses,
  evaluate,
  fontStyleTag,
  renderChord,
  hasChordContents,
  pangoToHtml,
  stripPangoMarkup,
  processMetadata,
};
