import Chord from '../chord';
import ChordDefinition from '../chord_definition/chord_definition';
import ChordDefinitionSet from '../chord_definition/chord_definition_set';
import ChordLyricsPair from './chord_lyrics_pair';
import Configuration from '../formatter/configuration';
import FormattingContext from '../formatter/formatting_context';
import Item from './item';
import Key from '../key';
import Line from './line';
import LineExpander from './line_expander';
import Literal from './chord_pro/literal';
import Metadata from './metadata';
import MetadataAccessors from './metadata_accessors';
import Paragraph from './paragraph';
import ParserWarning from '../parser/parser_warning';
import SongBuilder from '../song_builder';
import SongMapper from './song_mapper';
import Tag from './tag';

import { Accidental } from '../constants';
import { testSelector } from '../helpers';
import { CAPO, KEY } from './tags';
import { configurationProviders, staticProviders } from './standard_metadata_providers';
import { deprecate, filterObject } from '../utilities';

type MapItemsCallback = (_item: Item) => Item | Item[] | null;

/**
 * Represents a song in a chord sheet. Currently a chord sheet can only have one song.
 */
class Song extends MetadataAccessors {
  /**
   * The {@link Line} items of which the song consists
   * @member {Line[]}
   */
  lines: Line[] = [];

  _bodyLines: Line[] | null = null;

  _bodyParagraphs: Paragraph[] | null = null;

  _renderParagraphs: Paragraph[] | null = null;

  warnings: ParserWarning[] = [];

  _metadata: Metadata | null = null;

  /**
   * Creates a new {Song} instance
   * @param metadata {Record<string, string | string[]>|Metadata} predefined metadata
   */
  constructor(metadata: Record<string, string | string[]> | Metadata | null = null) {
    super();

    if (metadata) {
      this._metadata = new Metadata(metadata);
    }
  }

  /** Returns song lines, skipping leading empty/meta-only lines. @returns {Line[]} */
  get bodyLines(): Line[] {
    this._bodyLines ??= this.selectRenderableItems(this.lines) as Line[];
    return this._bodyLines;
  }

  /** Returns song paragraphs, skipping paragraphs with only empty lines. @returns {Paragraph[]} */
  get bodyParagraphs(): Paragraph[] {
    this._bodyParagraphs ??= this.selectRenderableItems(this.paragraphs) as Paragraph[];
    return this._bodyParagraphs;
  }

  get renderParagraphs(): Paragraph[] {
    return this._renderParagraphs ?? this.bodyParagraphs;
  }

  set renderParagraphs(paragraphs: Paragraph[]) { this._renderParagraphs = paragraphs; }

  selectRenderableItems(items: (Line | Paragraph)[]): (Line | Paragraph)[] {
    const copy = [...items];
    while (copy.length && !copy[0].hasRenderableItems()) copy.shift();
    return copy;
  }

  /** The {@link Paragraph} items of which the song consists @member {Paragraph[]} */
  get paragraphs(): Paragraph[] { return this.linesToParagraphs(this.lines); }

  /** The body paragraphs with any `{chorus}` tag expanded into the targeted chorus */
  get expandedBodyParagraphs(): Paragraph[] {
    const expandedLines = this.lines.flatMap((line: Line) => LineExpander.expand(line, this));
    return this.selectRenderableItems(this.linesToParagraphs(expandedLines)) as Paragraph[];
  }

  filterParagraphs(paragraphs: Paragraph[], configuration: Configuration): Paragraph[] {
    const context: FormattingContext = { configuration, metadata: this.metadata };

    return paragraphs.filter((paragraph) => {
      const { selector, selectorIsNegated } = paragraph;

      if (!selector) return true;

      return testSelector({ selector, isNegated: selectorIsNegated }, context);
    });
  }

  linesToParagraphs(lines: Line[]): Paragraph[] {
    let currentParagraph = new Paragraph();
    const paragraphs = [currentParagraph];
    lines.forEach((line, index) => {
      const nextLine: Line | null = lines[index + 1] || null;
      if (line.isEmpty() || (line.isSectionEnd() && nextLine && !nextLine.isEmpty())) {
        currentParagraph = new Paragraph();
        paragraphs.push(currentParagraph);
      } else if (line.hasRenderableItems()) {
        currentParagraph.addLine(line);
      }
    });
    return paragraphs;
  }

  /** Returns a deep clone of the song @returns {Song} */
  clone(): Song {
    const clone = new Song();
    clone.warnings = [...this.warnings];
    clone.lines = this.lines.map((line) => line.clone());
    return clone;
  }

  getMetadataValue(name: string): string | string[] | null {
    return this.metadata.getMetadataValue(name);
  }

  getSingleMetadataValue(name: string): string | null {
    return this.metadata.getSingleMetadataValue(name);
  }

  /**
   * Returns a copy of the song with the key value set to the specified key. It changes:
   * - the value for `key` in the {@link metadata} set
   * - any existing `key` directive
   * @param {number|null} key the key. Passing `null` will:
   * - remove the current key from {@link metadata}
   * - remove any `key` directive
   * @returns {Song} The changed song
   */
  setKey(key: string | number | null): Song {
    const strKey = key ? key.toString() : null;
    return this.changeMetadata(KEY, strKey);
  }

  /**
   * Returns a copy of the song with the key value set to the specified capo. It changes:
   * - the value for `capo` in the {@link metadata} set
   * - any existing `capo` directive
   * @param {number|null} capo the capo. Passing `null` will:
   * - remove the current key from {@link metadata}
   * - remove any `capo` directive
   * @returns {Song} The changed song
   */
  setCapo(capo: number | null): Song {
    const strCapo = capo ? capo.toString() : null;
    return this.changeMetadata(CAPO, strCapo);
  }

  private updateDirectives(metadata: Record<string, string | string[] | null>): Song {
    const updates = { ...metadata };

    const newMetadata: Record<string, string | string[] | null> =
      filterObject<string | string[] | null>(updates, (key, value) => (
        value !== null && !this.metadata.contains(key)
      ));

    const updatedSong = this.changeOrDeleteDirectives(updates);
    updatedSong.insertDirectives(newMetadata);
    return updatedSong;
  }

  private changeOrDeleteDirectives(updates: Record<string, string | string[] | null>) {
    const pendingUpdates = { ...updates };

    return this.mapItems((item: Item) => {
      if (!(item instanceof Tag)) {
        return item;
      }

      const tag = item as Tag;

      if (!(tag.name in pendingUpdates && tag.isMetaTag())) {
        return item;
      }

      const replacementValue = pendingUpdates[tag.name];

      if (replacementValue === null) {
        return null;
      }

      pendingUpdates[tag.name] = null;

      return [replacementValue].flat().map((value) => new Tag(tag.name, value));
    });
  }

  private insertDirectives(metadata: Record<string, string | string[] | null>, { after = null } = {}): void {
    const insertIndex = this.findInsertIndex(after);
    const finalInsertIndex = this.adjustInsertIndex(insertIndex);
    const newLines = this.createMetadataLines(metadata);
    const linesToInsert = this.prepareLinesToInsert(newLines, insertIndex, finalInsertIndex);
    this.spliceLines(finalInsertIndex, linesToInsert);
  }

  private findInsertIndex(after: string | null): number {
    return this.lines.findIndex((line) => (
      line.items.some((item) => this.isInsertionPoint(item, after))
    ));
  }

  private isInsertionPoint(item: Item, after: string | null): boolean {
    if (!(item instanceof Tag)) return true;
    if (after && item.name === after) return true;
    return item.isComment() || item.isSectionDelimiter();
  }

  private adjustInsertIndex(insertIndex: number): number {
    if (insertIndex <= 0) return insertIndex;

    for (let i = insertIndex - 1; i >= 0; i -= 1) {
      if (!this.lines[i].isEmpty()) return i + 1;
    }
    return 0;
  }

  private createMetadataLines(metadata: Record<string, string | string[] | null>): Line[] {
    return Object.keys(metadata).flatMap((name) => {
      const values = [metadata[name]].flat();
      return values.map((value) => {
        const line = new Line();
        line.addTag(name, value);
        return line;
      });
    });
  }

  private prepareLinesToInsert(newLines: Line[], insertIndex: number, finalInsertIndex: number): Line[] {
    const linesToInsert = [...newLines];
    const hasEmptyLineBetween = insertIndex > finalInsertIndex &&
      this.lines.slice(finalInsertIndex, insertIndex).some((line) => line.isEmpty());

    if (!hasEmptyLineBetween && newLines.length > 0) {
      linesToInsert.push(new Line());
    }
    return linesToInsert;
  }

  private spliceLines(index: number, linesToInsert: Line[]): void {
    const { lines } = this;
    this.lines = [...lines.slice(0, index), ...linesToInsert, ...lines.slice(index)];
  }

  /**
   * Transposes the song by the specified delta. It will:
   * - transpose all chords, see: {@link Chord#transpose}
   * - transpose the song key in {@link metadata}
   * - update any existing `key` directive
   * @param {number} delta The number of semitones (positive or negative) to transpose with
   * @param {Object} [options={}] options
   * @param {boolean} [options.normalizeChordSuffix=false] whether to normalize the chord suffixes after transposing
   * @returns {Song} The transposed song
   */
  transpose(
    delta: number,
    { accidental = null, normalizeChordSuffix = false }:
      { accidental?: Accidental | null, normalizeChordSuffix?: boolean } = {},
  ): Song {
    let transposedKey: Key | null = null;

    return this.mapItems((item) => {
      if (item instanceof Tag && item.name === KEY) {
        transposedKey = Key.wrapOrFail(item.value).transpose(delta).normalize();
        if (accidental) transposedKey = transposedKey.useAccidental(accidental);
        return item.set({ value: transposedKey.toString() });
      }
      if (item instanceof ChordLyricsPair) {
        return Song.transposeChordLyricsPair(item, delta, transposedKey, normalizeChordSuffix, accidental);
      }
      if (item instanceof Literal) {
        return Song.transposeLiteral(item, delta, transposedKey, normalizeChordSuffix, accidental);
      }
      return item;
    });
  }

  private static transposeChordLyricsPair(
    item: ChordLyricsPair,
    delta: number,
    transposedKey: Key | null,
    normalizeChordSuffix: boolean,
    accidental: Accidental | null,
  ): ChordLyricsPair {
    let chord = item.transpose(delta, transposedKey, { normalizeChordSuffix });
    if (accidental) chord = chord.useAccidental(accidental);
    return chord;
  }

  private static transposeLiteral(
    item: Literal,
    delta: number,
    transposedKey: Key | null,
    normalizeChordSuffix: boolean,
    accidental: Accidental | null,
  ): Literal {
    return Song.mapChordsInLiteral(item, (chord) => {
      let transposed = chord.transpose(delta);
      if (transposedKey) transposed = transposed.normalize(transposedKey, { normalizeSuffix: normalizeChordSuffix });
      if (accidental) transposed = transposed.useAccidental(accidental);
      return transposed;
    });
  }

  /**
   * Transposes the song up by one semitone. It will:
   * - transpose all chords, see: {@link Chord#transpose}
   * - transpose the song key in {@link metadata}
   * - update any existing `key` directive
   * @param {Object} [options={}] options
   * @param {boolean} [options.normalizeChordSuffix=false] whether to normalize the chord suffixes after transposing
   * @returns {Song} The transposed song
   */
  transposeUp({ normalizeChordSuffix = false }: { normalizeChordSuffix?: boolean; } = {}): Song {
    return this.transpose(1, { normalizeChordSuffix });
  }

  /**
   * Transposes the song down by one semitone. It will:
   * - transpose all chords, see: {@link Chord#transpose}
   * - transpose the song key in {@link metadata}
   * - update any existing `key` directive
   * @param {Object} [options={}] options
   * @param {boolean} [options.normalizeChordSuffix=false] whether to normalize the chord suffixes after transposing
   * @returns {Song} The transposed song
   */
  transposeDown({ normalizeChordSuffix = false }: { normalizeChordSuffix?: boolean; } = {}): Song {
    return this.transpose(-1, { normalizeChordSuffix });
  }

  /**
   * Returns a copy of the song with the key set to the specified key. It changes:
   * - the value for `key` in the {@link metadata} set
   * - any existing `key` directive
   * - all chords, those are transposed according to the distance between the current and the new key
   * @param {string} newKey The new key.
   * @returns {Song} The changed song
   */
  changeKey(newKey: string | Key): Song {
    const currentKey = this.requireCurrentKey();
    const targetKey = Key.wrapOrFail(newKey);
    const delta = currentKey.distanceTo(targetKey);
    return this.transpose(delta, { accidental: targetKey.accidental });
  }

  /**
   * Returns a copy of the song with all chords changed to the specified accidental.
   *
   * Examples:
   *
   * ```js
   * song.useAccidental('#');
   * song.useAccidental('b');
   * ```
   *
   * @param {Accidental} accidental the new accidental
   * @returns {Song} the changed song
   */
  useAccidental(accidental: Accidental): Song {
    const { currentKey } = this;
    let changedSong = this.mapChordLyricsPairs((pair) => pair.useAccidental(accidental));

    if (currentKey && currentKey.accidental !== accidental) {
      changedSong = changedSong.changeKey(currentKey.useAccidental(accidental));
    }

    return changedSong;
  }

  /**
   * @deprecated Use useAccidental instead
   */
  useModifier(accidental: Accidental): Song {
    deprecate('useModifier is deprecated, use useAccidental instead');
    return this.useAccidental(accidental);
  }

  /**
   * Returns a copy of the song with all chords normalized to the specified key. See {@link Chord#normalize}.
   * @param key the key to normalize to
   * @param options options
   * @param options.normalizeSuffix whether to normalize the chord suffixes
   */
  normalizeChords(
    key: Key | string | null = null,
    { normalizeSuffix = true }: { normalizeSuffix?: boolean; } = {},
  ): Song {
    return this.changeChords((chord) => chord.normalize(key, { normalizeSuffix }));
  }

  mapChordLyricsPairs(func: (pair: ChordLyricsPair) => ChordLyricsPair): Song {
    return this.mapItems((item) => {
      if (item instanceof ChordLyricsPair) {
        return func(item);
      }

      return item;
    });
  }

  changeChords(func: (chord: Chord) => Chord): Song {
    return this.mapItems((item) => {
      if (item instanceof ChordLyricsPair) {
        return item.changeChord(func);
      }
      if (item instanceof Literal) {
        return Song.mapChordsInLiteral(item, func);
      }
      return item;
    });
  }

  private static mapChordsInLiteral(item: Literal, func: (chord: Chord) => Chord): Literal {
    // Handle space-separated chords in grid format (e.g., "|| Am . . | C . |")
    const changedString = item.string.replace(/(\s|^)(\S+)(?=\s|$)/g, (_match, space, token) => {
      const chord = Chord.parse(token);
      if (!chord) return `${space}${token}`;
      return `${space}${func(chord).toString()}`;
    });
    return new Literal(changedString);
  }

  get currentKey(): Key | null {
    return Key.wrap(this.key);
  }

  requireCurrentKey(): Key {
    const { currentKey } = this;

    if (!currentKey) {
      throw new Error(`
Cannot change song key, the original key is unknown.

Either ensure a key directive is present in the song (when using chordpro):
  \`{key: C}\`

Or set the song key before changing key:
  \`song.setKey('C');\``.substring(1));
    }

    return currentKey;
  }

  /**
   * Returns a copy of the song with the directive value(s) set to the specified value(s).
   * - when there is a matching directive in the song, it will update the directive
   * - when there is no matching directive, it will be inserted
   * If `value` is `null` it will act as a delete, any directive matching `name` will be removed.
   *
   * @example
   * ```javascript
   * song.changeMetadata('author', 'John');
   * song.changeMetadata('composer', ['Jane', 'John']);
   * song.changeMetadata('key', null); // Remove key directive
   * ```
   * @param name The directive name
   * @param {string | string[] | null} value The value to set, or `null` to remove the directive
   * @return {Song} The changed song
   */
  changeMetadata(name: string, value: string | string[] | null): Song;

  /**
   * Returns a copy of the song with the metadata changed. It will:
   * - update the metadata
   * - update any existing directive matching the metadata key
   * - insert a new directive if it does not exist
   * @example
   * ```javascript
   * song.changeMetadata({
   *   author: 'John',
   *   composer: ['Jane', 'John'],
   *   key: null, // Remove key directive
   * });
   * ```
   * @param {Record<string, string | string[] | null>} metadata The metadata to change
   */
  changeMetadata(metadata: Record<string, string | string[] | null>): Song;

  changeMetadata(
    nameOrData: string | Record<string, string | string[] | null>,
    value?: string | string[] | null,
  ): Song {
    if (typeof nameOrData === 'string') {
      if (typeof value === 'undefined') {
        throw new Error('Value is required when name is a string');
      }

      return this.changeMetadata({ [nameOrData]: value });
    }

    const updatedSong = this.updateDirectives(nameOrData);
    updatedSong.metadata.assign(nameOrData);
    return updatedSong;
  }

  addLine(line: Line) {
    this.lines.push(line);
  }

  /**
   * Change the song contents inline. Return a new {@link Item} to replace it. Return `null` to remove it.
   * @example
   * // transpose all chords:
   * song.mapItems((item) => {
   *   if (item instanceof ChordLyricsPair) {
   *     return item.transpose(2, 'D');
   *   }
   *
   *   return item;
   * });
   * @param {MapItemsCallback} func the callback function
   * @returns {Song} the changed song
   */
  mapItems(func: MapItemsCallback): Song {
    return new SongMapper(this).mapItems(func);
  }

  foreachItem(func: (_item: Item) => void): void {
    this.lines.forEach((line) => {
      line.items.forEach(func);
    });
  }

  /**
   * Returns all unique chords used in the song
   * @returns {string[]} the chords
   */
  getChords(): string[] {
    const chords = new Set<string>();

    this.foreachItem((item: Item) => {
      if (!(item instanceof ChordLyricsPair)) {
        return;
      }

      const itemChords = (item as ChordLyricsPair).chords;

      if (itemChords && itemChords.length > 0) {
        const parsedChord = Chord.parse(itemChords);

        if (parsedChord) {
          chords.add(parsedChord.toString());
        }
      }
    });

    return Array.from(chords);
  }

  /**
   * Returns all chord definitions from the song.
   * Definitions are made using the `{chord}` or `{define}` directive.
   * A chord definitions overrides a previous chord definition for the exact same chord.
   * @returns {Record<string, ChordDefinition>} the chord definitions
   * @see https://chordpro.org/chordpro/directives-define/
   * @see https://chordpro.org/chordpro/directives-chord/
   */
  getChordDefinitions(context?: FormattingContext): Record<string, ChordDefinition> {
    const chordDefinitions: Record<string, ChordDefinition> = {};

    this.foreachItem((item: Item) => {
      if (!(item instanceof Tag)) {
        return;
      }

      const { chordDefinition, selector, isNegated } = (item as Tag);

      if (selector && context && !testSelector({ selector, isNegated }, context)) {
        return;
      }

      if (chordDefinition) {
        chordDefinitions[chordDefinition.name] = chordDefinition.clone();
      }
    });

    return chordDefinitions;
  }

  /**
   * The song's metadata. When there is only one value for an entry, the value is a string. Else, the value is
   * an array containing all unique values for the entry.
   * @type {Metadata}
   */
  get metadata(): Metadata {
    if (!this._metadata) {
      this._metadata = this.getMetadata();
    }

    return this._metadata;
  }

  getMetadata(configuration?: Configuration): Metadata {
    const metadata = new Metadata();

    const providers = configuration ? configurationProviders(configuration) : staticProviders();
    providers.forEach((provider, key) => metadata.setProvider(key, provider));

    const chords = () => this.getChords();
    metadata.setProvider('chords', () => { const c = chords(); return c.length ? c.join(', ') : null; });
    metadata.setProvider('numchords', () => chords().length.toString());
    metadata.setProvider('key_actual', () => metadata.getSingle('_key') ?? metadata.getSingle('key'));
    metadata.setProvider('key_from', () => metadata.getSingle('key'));

    this.foreachItem((item: Item) => {
      if (!(item instanceof Tag)) {
        return;
      }

      const tag = item as Tag;

      if (!tag.isMetaTag()) {
        return;
      }

      const { selector, isNegated } = tag;

      if (selector && configuration && !testSelector({ selector, isNegated }, { metadata, configuration })) {
        return;
      }

      metadata.add(item.name, item.value);
    });

    return metadata;
  }

  get chordDefinitions(): ChordDefinitionSet {
    return new ChordDefinitionSet(this.getChordDefinitions());
  }

  /**
   * Change the song contents inline. Return a new {@link Line} to replace it. Return `null` to remove it.
   * @example
   * // remove lines with only Tags:
   * song.mapLines((line) => {
   *   if (line.items.every(item => item instanceof Tag)) {
   *     return null;
   *   }
   *
   *   return line;
   * });
   * @param {MapLinesCallback} func the callback function
   * @returns {Song} the changed song
   */
  mapLines(func: (_line: Line) => Line | null): Song {
    const clonedSong = new Song();
    const builder = new SongBuilder(clonedSong);

    this.lines.forEach((line) => {
      const changedLine = func(line);

      if (changedLine) {
        builder.addLine();
        changedLine.items.forEach((item) => builder.addItem(item));
      }
    });

    return clonedSong;
  }

  private updateItem(
    findCallback: (_item: Item) => boolean,
    updateCallback: (_item: Item) => Item,
    notFoundCallback: (_song: Song) => Song,
  ): Song {
    let found = false;

    const updatedSong = this.mapItems((item) => {
      if (findCallback(item)) {
        found = true;
        return updateCallback(item);
      }

      return item;
    });

    if (!found) {
      return notFoundCallback(updatedSong);
    }

    return updatedSong;
  }

  private removeItem(callback: (_item: Item) => boolean): Song {
    return this.mapLines((line) => {
      const { items } = line;
      const index = items.findIndex(callback);

      if (index === -1) {
        return line;
      }

      if (items.length === 1) {
        return null;
      }

      return line.set({
        items: [...items.slice(0, index), ...items.slice(index + 1)],
      });
    });
  }
}

export default Song;
