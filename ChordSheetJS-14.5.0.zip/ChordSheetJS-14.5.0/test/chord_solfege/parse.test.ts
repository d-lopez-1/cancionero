import '../util/matchers';

import { Chord, SOLFEGE } from '../../src';

describe('Chord', () => {
  describe('chord solfege', () => {
    describe('parse', () => {
      describe('chord without bass', () => {
        it('parses a simple chord', () => {
          const chord = Chord.parse('Mi');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 4,
              originalKeyString: 'Mi',
            },
            bass: null,
            suffix: null,
            quality: null,
            extensions: null,
          });
        });

        it('parses a chord with suffix', () => {
          const chord = Chord.parse('Misus');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 4,
              originalKeyString: 'Mi',
            },
            bass: null,
            suffix: 'sus',
            quality: 'sus',
            extensions: null,
          });
        });

        it('parses a minor chord', () => {
          const chord = Chord.parse('Lam');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: true,
              referenceKeyGrade: 9,
              originalKeyString: 'La',
            },
            bass: null,
            suffix: 'm',
            quality: 'm',
            extensions: null,
          });
        });

        it('parses a diminished chord', () => {
          const chord = Chord.parse('Sidim');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 11,
              originalKeyString: 'Si',
            },
            bass: null,
            suffix: 'dim',
            quality: 'dim',
            extensions: null,
          });
        });

        it('parses an augmented chord', () => {
          const chord = Chord.parse('Doaug');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 0,
              originalKeyString: 'Do',
            },
            bass: null,
            suffix: 'aug',
            quality: 'aug',
            extensions: null,
          });
        });

        it('parses a sus2 chord', () => {
          const chord = Chord.parse('Resus2');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 2,
              originalKeyString: 'Re',
            },
            bass: null,
            suffix: 'sus2',
            quality: 'sus2',
            extensions: null,
          });
        });

        it('parses a sus4 chord', () => {
          const chord = Chord.parse('Solsus4');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 7,
              originalKeyString: 'Sol',
            },
            bass: null,
            suffix: 'sus4',
            quality: 'sus4',
            extensions: null,
          });
        });

        it('parses a chord with modifier', () => {
          const chord = Chord.parse('Fa#');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 6,
              originalKeyString: 'Fa',
            },
            bass: null,
            suffix: null,
            quality: null,
            extensions: null,
          });
        });

        it('parses a chord with modifier and suffix', () => {
          const chord = Chord.parse('Fa#sus');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 6,
              originalKeyString: 'Fa',
            },
            bass: null,
            suffix: 'sus',
            quality: 'sus',
            extensions: null,
          });
        });

        it('parses a chord with confusing suffix #11', () => {
          const chord = Chord.parse('Fama9(#11)');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 5,
              originalKeyString: 'Fa',
            },
            bass: null,
            suffix: 'ma9(#11)',
            quality: null,
            extensions: 'ma9(#11)',
          });
        });

        it('parses a chord with modifier and confusing suffix', () => {
          const chord = Chord.parse('Fa#maj9b11');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 6,
              originalKeyString: 'Fa',
            },
            bass: null,
            suffix: 'maj9b11',
            quality: null,
            extensions: 'maj9b11',
          });
        });

        it('parses a chord with confusing suffix #9', () => {
          const chord = Chord.parse('La7(#9)');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 9,
              originalKeyString: 'La',
            },
            bass: null,
            suffix: '7(#9)',
            quality: null,
            extensions: '7(#9)',
          });

          expect(chord?.toString()).toEqual('La7(#9)');
        });
      });

      describe('chord with bass', () => {
        it('parses a simple chord', () => {
          const chord = Chord.parse('Mi/Si');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 4,
              originalKeyString: 'Mi',
            },
            bass: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 11,
              originalKeyString: 'Si',
            },
            suffix: null,
            quality: null,
            extensions: null,
          });
        });

        it('parses a chord with suffix', () => {
          const chord = Chord.parse('Misus/Si');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 4,
              originalKeyString: 'Mi',
            },
            bass: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 11,
              originalKeyString: 'Si',
            },
            suffix: 'sus',
            quality: 'sus',
            extensions: null,
          });
        });

        it('parses a chord with modifier', () => {
          const chord = Chord.parse('Fa#/Do#');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 6,
              originalKeyString: 'Fa',
            },
            bass: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 1,
              originalKeyString: 'Do',
            },
            suffix: null,
            quality: null,
            extensions: null,
          });
        });

        it('parses a chord with modifier and suffix', () => {
          const chord = Chord.parse('Fa#sus/Do#');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 6,
              originalKeyString: 'Fa',
            },
            bass: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 1,
              originalKeyString: 'Do',
            },
            suffix: 'sus',
            quality: 'sus',
            extensions: null,
          });
        });

        it('parses a chord with confusing suffix', () => {
          const chord = Chord.parse('Fama9(#11)/Do#');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 5,
              originalKeyString: 'Fa',
            },
            bass: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 1,
              originalKeyString: 'Do',
            },
            suffix: 'ma9(#11)',
            quality: null,
            extensions: 'ma9(#11)',
          });
        });

        it('parses a chord with modifier and confusing suffix', () => {
          const chord = Chord.parse('Fa#maj9b11/Do#');

          expect(chord).toMatchObject({
            root: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 6,
              originalKeyString: 'Fa',
            },
            bass: {
              grade: 0,
              accidental: '#',
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 1,
              originalKeyString: 'Do',
            },
            suffix: 'maj9b11',
            quality: null,
            extensions: 'maj9b11',
          });
        });
      });

      it('allows whitespace', () => {
        const chord = Chord.parse(' \n Fa#/Do# \r ');

        expect(chord).toMatchObject({
          root: {
            grade: 0,
            accidental: '#',
            type: SOLFEGE,
            minor: false,
            referenceKeyGrade: 6,
            originalKeyString: 'Fa',
          },
          bass: {
            grade: 0,
            accidental: '#',
            type: SOLFEGE,
            minor: false,
            referenceKeyGrade: 1,
            originalKeyString: 'Do',
          },
          suffix: null,
          quality: null,
          extensions: null,
        });
      });

      describe('chord with only a bass', () => {
        it('parses a simple chord with no base', () => {
          const chord = Chord.parse('/Si');

          expect(chord).toMatchObject({
            root: null,
            bass: {
              grade: 0,
              accidental: null,
              type: SOLFEGE,
              minor: false,
              referenceKeyGrade: 11,
              originalKeyString: 'Si',
            },
            suffix: null,
            quality: null,
            extensions: null,
          });

          expect(chord?.toString()).toEqual('/Si');
        });
      });
    });
  });
});
